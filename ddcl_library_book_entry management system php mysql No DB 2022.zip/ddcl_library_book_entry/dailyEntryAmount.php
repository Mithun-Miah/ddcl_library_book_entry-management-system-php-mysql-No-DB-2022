<!DOCTYPE html>
<html lang="en">
<head>
    <title>Daily Entry Amount</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="dailyEntryAmount.css">

    <style>
        .printDiv {
        text-align: center;
        }
        #printBtn {
        border: none;
        background-color: yellow;
        font-size: 16px;
        padding: 10px;
        border-radius: 10px;
        cursor: pointer;
        box-shadow: 1px 1px 1px black;
        transition: 0.2s;
        }
        #printBtn:hover {
        background-color: blue;
        color: white;
        }
        .monthDiv {
        margin-bottom: 10px;
        }
        .monthDiv lable {
        font-size: 22px;
        font-weight: 700;
        }
        .monthDiv input {
        font-size: 22px;
        font-weight: 700;
        }
        .inputData {
        padding: 20px;
        }
        .inputData label {
        font-size: 20px;
        font-weight: 600;
        }
        .inputData input {
        font-size: 16px;
        font-weight: 600;
        padding: 5px;
        }
        #addBtn {
        border: none;
        background-color: blue;
        color: white;
        font-size: 16px;
        padding: 10px;
        border-radius: 10px;
        cursor: pointer;
        box-shadow: 1px 1px 1px black;
        transition: 0.2s;
        }
        table {
        border: 1px solid black;
        /* text-align: center; */
        margin: auto;
        }
    </style>
</head>
<body>

    <div class="container">
    <div id="topTitleDiv">
            <img src="img/Hydrangeas.jpg" alt="Pic"/>
            <span>User Name : MD.MITHUN MIAH > Business : DDCL > Module : DDC Library</span>
            <a href="mainWindow.php" class="btnHome" title="Main Window"><i class="fa-solid fa-house"></i></a> 
            <a href="logout.php" title="Logout" class="btnClose"><i class="fa-solid fa-square-xmark"></i></a>
            </div>
            <hr/>
        
            <div id="topManuDiv">
    
                <div class="dropdown">
                    <button onclick="myFunction()" class="dropbtn">Entry Menu</button>
                    <div id="myDropdown" class="dropdown-content">
                    <a href="dailyUpdate.php">Daily Update</a>
                    <a href="dailyEntryAmount.php">Daily Entry Amount</a>
                    <a href="publisherEntry.php">Publisher Entry</a>
                    </div>
    
                    <button onclick="myFunctionRepo()" class="dropbtn">Reports</button>
                    <div id="myDropdownRepo" class="dropdown-content">
                      <a href="bookList.php">Book List</a>
                    </div>
                    
                  </div>
    
            </div>
        
            <div id="bnCheckbox">
            <label> Book Entry </label> 
            <input type="checkbox"/>
            </div>
    </div>

    <section>
        <div class="printDiv">
            <h2>DDC Library Book Data Entry List</h2>
            <h2>Mithun Miah</h2>
            <h3>Monthly (English Books) Update Reports</h3>
            <div class="monthDiv">
            <lable>Month Name => </lable><input type="month">
            </div>
            <div>
                <button id="printBtn">Print Reports</button>
            </div>
            <hr>
            <div class="calcu">
                <div class="inputData">
                    <label for="">Days Sl. No. : </label>
                    <input type="text">
                    <label for="">Date : </label>
                    <input type="date">
                    <label for="">Amount of Books : </label>
                    <input type="number">
                    <input type="button" name="submit" id="addBtn" value="Add">
                </div>
                <table>
                    <thead>
                        <th>Days Sl. No.</th>
                        <th>Date</th>
                        <th>Amount of Books</th>
                    </thead>
                    <tbody>
                        <tr>
                            <td>01</td>
                            <td>Today</td>
                            <td>100</td>
                        </tr>
                    </tbody>
                </table>
            </div>

        </div>
    </section>
    

    <script>
        /* When the user clicks on the button, 
        toggle between hiding and showing the dropdown content */
        function myFunction() {
          document.getElementById("myDropdown").classList.toggle("show");
        }

        function myFunctionRepo() {
          document.getElementById("myDropdownRepo").classList.toggle("show");
        }

        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }
        
        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }

        
        </script>
</body>
</html>