<?php
// For Store data
session_start();
//database connection
$connection = mysqli_connect('localhost','root','','ddcl_library_book_entry_db');
//database connection check
if($connection){
    echo "Connection Success";
} else{
    echo "Connection Failed";
}

//Select html form name attribute
if(isset($_POST['loginBtn'])){
    $employeeId = $_POST['employeeId'];
    $password = $_POST['password'];

    $select = "SELECT * FROM registration_table where employeeId = '$employeeId' AND password = '$password' ";
    $query = mysqli_query($connection, $select);

    $fetch = mysqli_fetch_array($query);
    if($fetch){
        
        header('Location: mainWindow.php');
        // echo "<script>alert('Login Successful')</script>";
        // fetch email address from database to another page display
        $_SESSION['employeeId'] = $fetch['employeeId'];
        $_SESSION['first_name'] = $fetch['first_name'];

    }else{
        echo "<script>alert('Id and Password Not Matched')</script>";
    }
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login Form</title>
    <link rel="stylesheet" href="login.css">

    <style>
        .loginDiv {
            text-align: center;
            margin-right: 185px;
            margin-bottom: 60px;
        }
        .btnDiv {
            text-align: center;
            margin-top: auto;
            padding-right: 100px;
        }
        .forgetPassDiv{
            margin-top: 50px;
            text-align: end;
            width: 80%;
        }
        .forgetPassDiv a{
            font-size: 20px;
            font-weight: 600;
            text-decoration: none;
        }
    </style>
</head>
<body>

<div class="reg_container">
        <h1>Login</h1>
        <form method="POST">
            <label for="">Employee ID</label>
            <br>
            <input type="text" name="employeeId" require>
            <br><br>
            <label for="">Password</label>
            <br>
            <input type="password" name="password" require>
            <br><br>
            <div class="loginDiv">
            <button id="logBtn" name="loginBtn">Login</button>
            </div>
        </form>
        <div class="btnDiv">
        
        <a href="registration.php" id="regBtn">Create Account</a>
        </div>
        <div class="forgetPassDiv">
            <a href="forgotPass.php">Forgot Password ?</a>
        </div>
    </div>
    
</body>
</html>