<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['employeeId'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h1>Your Id : $_SESSION[employeeId]</h1>");
} else{
    header('Location: login.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Entry Menu</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="entryMenu.css">

</head>
<body>

    <div class="container">

        <div id="topTitleDiv">
        <img src="img/Hydrangeas.jpg" alt="Pic"/>
        <span>User Name : MD.MITHUN MIAH > Business : DEVELOPMENT DESIGN CONSULTANTS LTD. > Module : DDC Library</span>
        <a href="mainWindow.php" class="btnHome" title="Main Window"><i class="fa-solid fa-house"></i></a> 
        <a href="logout.php" title="Logout" class="btnClose"><i class="fa-solid fa-square-xmark"></i></a>
        </div>
        <hr/>
    
        <div id="topManuDiv">

            <div class="dropdown">
                <button onclick="myFunction()" class="dropbtn">Entry Menu</button>
                <div id="myDropdown" class="dropdown-content">
                  <a href="dailyUpdate.php">Daily Update</a>
                  <a href="dailyEntryAmount.php">Daily Entry Amount</a>
                  <a href="publisherEntry.php">Publisher Entry</a>
                </div>

                <button onclick="myFunctionRepo()" class="dropbtn">Reports</button>
                <div id="myDropdownRepo" class="dropdown-content">
                  <a href="bookList.php">Book List</a>
                </div>
                
              </div>

        </div>
    
        <div id="bnCheckbox">
        <label> Book Entry </label> 
        <input type="checkbox"/>
        </div>

        <div id="footerDiv">
            <p>Powered by Me</p>
        </div>
    
    </div>
    


    <script>
        /* When the user clicks on the button, 
        toggle between hiding and showing the dropdown content */
        function myFunction() {
          document.getElementById("myDropdown").classList.toggle("show");
        }

        function myFunctionRepo() {
          document.getElementById("myDropdownRepo").classList.toggle("show");
        }

        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }
        
        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }

        
        </script>
</body>
</html>