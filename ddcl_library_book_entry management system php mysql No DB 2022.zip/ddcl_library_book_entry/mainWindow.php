<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['employeeId'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h3>Your Id : $_SESSION[employeeId]</h3>");
    echo("<h3>Your Name : $_SESSION[first_name]</h3>");
} else{
    header('Location: login.php');
}

// database connection
$connection = mysqli_connect('localhost', 'root', '', 'ddcl_library_book_entry_db');

//$msg=$fname=$lname=$dateofbirth=$gender=$email=$password=$confirm_password= "";

if($connection){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HOME Page</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="mainWindow.css">

    <style>
        .owner-title {
            padding: 5px 5px;
            color: #fff;
        }
       .logo{
           background-color: brown;
           display: grid;
           grid-template-columns: 1fr 1fr;
           justify-content: space-around;
           align-items: center;
       }
       .msg-close-btn{
           text-align: right;
           padding-right: 10px;
       }
       .msg-close-btn a{
           font-size: 25px;
       }
       .msg-close-btn i{
           color: #fff;
       }
       .company-info{
           background-color: red;
           height: 100px;
           margin: 10px 0px;
           padding: 10px;
           display: flex;
           align-items: center;
       }
       /* .logo-company{
            margin-right: 5px;
        } */
        .logo-company img{
            width: 150px;
        }
       .user-present-info{
           background-color: #a0a2e1;
           height: 100px;
            padding: 10px;
       }
       .company-address{
           text-align: left;
           margin-left: 5px;
           padding: 5px 5px;
           color: #fff;
           font-family: 'Lucida Sans', 'Lucida Sans Regular', 'Lucida Grande', 'Lucida Sans Unicode', Geneva, Verdana, sans-serif;
       }
       .company-address h4{
           margin: 0px;
           padding: 0px;
       }
       .company-address p{
           margin: 0px;
           padding: 0px;
       }
    </style>
</head>
<body>

    <div class="container">

        <div class="side-bar">
            <div class="wrap-icons">
                <div><a href="#"><i class="fa-solid fa-desktop"></i></a></div>
                <div><a href="#"><i class="fa-solid fa-file-zipper"></i></a></div>
                <div><a href="#"><i class="fa-solid fa-book"></i></a></div>
                <div><a href="#"><i class="fa-solid fa-calendar-days"></i></a></div>
                <div><a href="#"><i class="fa-solid fa-folder-open"></i></a></div>
                <div><a href="#"><i class="fa-solid fa-gear"></i></a></div>
            </div>
        </div>

        <div class="user-information">
            <div class="info-box">
                <a href="passwordChange.php" id="changePass">Change Password</a>
                <h3>USER INFORMATION</h3>
                <img src="img/Hydrangeas.jpg" alt="user img">
                <h4>MD. MITHUN MIAH</h4>
                <a href="entryMenu.php" id="user-name">DDC Library</a>
            </div>
        </div>

        <div class="content">
            
            <div class="logo">
                <div class="owner-title">
                    <h2>Powered by Me</h2>
                </div>
                
                <div class="msg-close-btn">
                    <a href="message.php" id="messageSend" title="Message"><i class="fa-solid fa-message"></i></a>
                    <a href="logout.php" id="closeWindow" title="Logout"><i class="fa-solid fa-square-xmark"></i></a>
                </div>
            </div>

            <div class="company-info">
                <div class="logo-company">
                    <img src="img/logo.png" alt="">
                </div>
                <div class="company-address">
                    <h4>DEVELOPMENT DESIGN CONSULTANTS LTD.</h4>
                    <p>"DDC Center", 47 Mohakhali C/A, Dhaka-1212, Bangladesh</p>
                    <small>For Support Please Call +88 01911601021 , +88 01966167016 | You Have To Archive The Daily Backups In a Secondary Storage ( Like Pen Drive or External HDD ) And Keep In a Safe Place.</small>
                </div>
            </div>

            <div class="user-present-info">
                <p>#  Current Date -  Wednesday, February 9, 2022</p>
                <p>#  Version Update Date - Tuesday, February 1, 2022</p>
                <p>#  Logged Smart ERP User - 45</p>
            </div>
        </div>

    </div>

    <div id="footerDiv">
        <p>Powered by Me</p>
    </div>
    
</body>
</html>