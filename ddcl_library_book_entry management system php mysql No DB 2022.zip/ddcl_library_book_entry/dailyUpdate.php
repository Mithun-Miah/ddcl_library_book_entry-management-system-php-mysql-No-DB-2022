<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['employeeId'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h3>Your Id : $_SESSION[employeeId]</h3>");
} else{
    header('Location: login.php');
}

//database connection
$connection = mysqli_connect('localhost','root','','ddcl_library_book_entry_db');

$msg=$slNo=$bookId=$bookLoc=$shelf=$entryDate=$updatedBy=$issue=$remarks= "";

//database connection check
if($connection){
    echo "Connection Success";
} else{
    echo "Connection Failed";
}

// select all html form name attribute
if (isset($_POST['submit'])) {
    $slNo = $_POST['slNo'];
    $bookId = $_POST['bookId'];
    $bookLoc = $_POST['bookLoc'];
    $shelf = $_POST['shelf'];
    $entryDate = $_POST['entryDate'];
    $updatedBy = $_POST['updatedBy'];
    $issue = $_POST['issue'];
    $remarks = $_POST['remarks'];

    // check duplicate email
    $book_id_check = "SELECT * FROM daily_update_tb where bookId = '$bookId' "; // select database column name and html form input name
    $book_id_query = mysqli_query($connection, $book_id_check); // Execute query
    $num_row = mysqli_num_rows($book_id_query); // check number of rows
    if($num_row>0){
        $msg = "This Book ID already exist, please try another ID"; // show duplicate email user input
    } else{
        // check password and confirm password
        if($bookId != 7){
            // check password special charecter and password length
            if(strlen($bookId) != 7){
                $msg = "***Please give id length must be 7 ***";

            } else{
                // data insert query working
                $insertData = "INSERT INTO daily_update_tb(slNo,bookId,bookLoc,shelf,entryDate,updatedBy,issue,remarks) 
                VALUES('$slNo','$bookId','$bookLoc','$shelf','$entryDate','$updatedBy','$issue','$remarks') ";

                $query = mysqli_query($connection, $insertData);
                if($query){
                    $msg = "Data Insert Success";
                } else{
                    $msg = "Data Insert Failed";
                }

            }
        } else{
            echo ("<script>alert('New Book Id does not correct !')</script>");
        }
        

    }
}

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Data Entry List</title>
    <style>
        * {
        box-sizing: border-box;
        }
        body {
        background-color: green;
        }
        a {
        text-decoration: none;
        }
        #topTitleDiv {
        padding: 10px 10px;
        margin-top: 5px;
        }
        #topTitleDiv img {
        width: 30px;
        height: 30px;
        }
        #topTitleDiv span {
        color: #fff;
        margin-right: 80px;
        }
        #topTitleDiv a {
        text-decoration: none;
        color: #fff;
        font-weight: bolder;
        }
        .btnHome {
        background-color: rgb(139, 221, 16);
        color: #fff;
        padding: 10px;
        border-radius: 5px;
        margin-left: 5px;
        margin-right: 5px;
        cursor: pointer;
        }
        .btnHome i {
        font-size: 20px;
        }
        .btnClose i {
        font-size: 20px;
        }
        .btnClose {
        background-color: red;
        padding: 10px;
        border-radius: 5px;
        cursor: pointer;
        }

        /* Top Menu Dropdown bar */
        #topManuDiv {
        padding: 10px 5px;
        margin-top: -8px;
        }
        #topManuDiv select {
        background-color: green;
        color: #fff;
        font-size: 0.9rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        cursor: pointer;
        }
        .dropbtn {
        background-color: #3498db;
        color: white;
        padding: 16px;
        font-size: 16px;
        border: none;
        cursor: pointer;
        }
        .dropbtn:hover,
        .dropbtn:focus {
        background-color: #2980b9;
        }

        .dropdown {
        position: relative;
        display: inline-block;
        }

        .dropdown-content {
        display: none;
        position: absolute;
        background-color: #f1f1f1;
        min-width: 160px;
        overflow: auto;
        box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
        z-index: 1;
        }

        .dropdown-content a {
        color: black;
        padding: 12px 16px;
        text-decoration: none;
        display: block;
        }

        .dropdown a:hover {
        background-color: #ddd;
        }

        .show {
        display: block;
        }

        /* Book Entry Checkbox */
        #bnCheckbox {
        background-color: #fff;
        padding: 5px 5px;
        text-align: right;
        }
        .container {
        width: 100%;
        /* height: 100vh; */
        border: 2px solid red;
        }

        #auth_rightSideInput {
        width: 100px;
        }

        /* Footer section */
        #footerDiv {
        background-color: cadetblue;
        width: 100%;
        border-radius: 5px;
        margin-top: 40%;
        margin-bottom: -15px;
        }
        #footerDiv p {
        text-transform: uppercase;
        padding: 10px 10px;
        color: #fff;
        text-align: end;
        text-shadow: 2px 0px 2px black;
        }
        form{
            display: grid;
            grid-template-columns: 1fr 1fr;
            justify-content: space-between;
            align-items: center;
            padding: 10px;
        }
        .left label{
            width: 150px;
            display: inline-block;
        }
        .left input{
            height: 35px;
            border-radius: 5px;
            padding: 5px;
            outline: none;
        }
        .right label{
            width: 100px;
            display: inline-block;
        }
        .right input{
            height: 35px;
            border-radius: 5px;
            padding: 5px;
            outline: none;
        }
        .right textarea{
            border-radius: 5px;
            padding: 5px;
            outline: none;
        }
        .submitBtn{
            width: 100px;
            background-color: #2980b9;
            color: white;
            border: none;
            cursor: pointer;
            font-size: 1.1rem;
            transition: 0.2s ease-in-out;
        }
        .submitBtn:hover{
            background-color: sienna;
            color: white;
        }
        .heading2{
            text-align: center;
            background-color: teal;
        }
        /* For Data Fetch Table Design */

        h1 {
            background-color: blue;
            color: white;
            padding: 10px;
            text-align: center;
        }
        table,th,td{
            border: 1px solid black;
            border-collapse: collapse;
            padding: 3px;
        }

    </style>
</head>
<body>

    <div class="container">
        <div id="topTitleDiv">
            <img src="img/Hydrangeas.jpg" alt="Pic"/>
            <span>User Name : MD.MITHUN MIAH > Business : DDCL > Module : DDC Library</span>
            <a href="mainWindow.php" class="btnHome" title="Main Window"><i class="fa-solid fa-house"></i></a> 
            <a href="logout.php" title="Logout" class="btnClose"><i class="fa-solid fa-square-xmark"></i></a>
            </div>
            <hr/>
        
            <div id="topManuDiv">
    
                <div class="dropdown">
                    <button onclick="myFunction()" class="dropbtn">Entry Menu</button>
                    <div id="myDropdown" class="dropdown-content">
                      <a href="dailyUpdate.php">Daily Update</a>
                      <a href="authorEntry.php">Author Entry</a>
                      <a href="publisherEntry.php">Publisher Entry</a>
                    </div>
    
                    <button onclick="myFunctionRepo()" class="dropbtn">Reports</button>
                    <div id="myDropdownRepo" class="dropdown-content">
                      <a href="bookList.php">Book List</a>
                    </div>
                    
                  </div>
    
            </div>
        
            <div id="bnCheckbox">
            <label> Book Entry </label> 
            <input type="checkbox"/>
            </div>

            <h2 class="heading2">DDC Library Book Data Entry List</h2>
            <h3><?php echo $msg;?></h3>
            <form action="" method="POST">

                <div class="left">
                    <label for="">SL. No. : </label>
                    <input type="number" name="slNo" value="<?php echo $slNo ?>">
                    <br><br>
                    <label for="">Book ID : </label>
                    <input type="text" name="bookId" value="<?php echo $bookId ?>">
                    <br><br>
                    <label for="">Book Location : </label>
                    <input type="text" name="bookLoc" value="<?php echo $bookLoc ?>">
                    <br><br>
                    <label for="">Shelf No : </label>
                    <input type="text" name="shelf" value="<?php echo $shelf ?>">
                    <br><br>
                    <label for="">Entry Date : </label>
                    <input type="datetime-local" name="entryDate" value="<?php echo $entryDate ?>">

                </div>
        
                <div class="right">
                    <label for="">Updated By : </label>
                    <input type="text" name="updatedBy" value="<?php echo $updatedBy ?>">
                    <br><br>
                    <label for="">Issue : </label>
                    <textarea name="issue" id="" cols="30" rows="6" value="<?php echo $issue ?>"></textarea>
                    <br><br>
                    <label for="">Remarks : </label>
                    <textarea name="remarks" id="" cols="30" rows="6" value="<?php echo $remarks ?>"></textarea>
                    <br><br>

                    <input type="submit" name="submit" class="submitBtn" value="Submit">
                </div>
            </form>

            <br>

        <h1>Read PHP Fetch Data From Database Table</h1>

        <table>
            <th>ID</th>
            <th>SL. No</th>
            <th>Book ID</th>
            <th>Book Location</th>
            <th>Shelf No</th>
            <th>Entry Date</th>
            <th>Updated By</th>
            <th>Issue</th>
            <th>Remarks</th>

        <?php
        $read = "SELECT * FROM daily_update_tb";
        $query = mysqli_query($connection, $read);
        
        //Database Rows Count Code
        // $count = mysqli_num_rows($query);
        // echo "<h3>Total Database Row : </h3>". $count;

        while($row = mysqli_fetch_array($query)){ ?>
            
            <tr>
                <td><?php echo $row["Id"];?></td>
                <td><?php echo $row["slNo"];?></td>
                <td><?php echo $row["bookId"];?></td>
                <td><?php echo $row["bookLoc"];?></td>
                <td><?php echo $row["shelf"];?></td>
                <td><?php echo $row["entryDate"];?></td>
                <td><?php echo $row["updatedBy"];?></td>
                <td><?php echo $row["issue"];?></td>
                <td><?php echo $row["remarks"];?></td>
                <td><a href="edit.php?idNo=<?php echo $row['Id']; ?>">edit</a></td>
                <td><a onclick="return confirm('Do You Want To Delete !')" href="delete.php?idNo=<?php echo $row['Id']; ?>">delete</a></td>
            </tr>

        <?php }
        
        ?>

        <!-- After refresh/reload Data Resubmission Stop with this code -->
        <script>
            if(window.history.replaceState){
                window.history.replaceState(null,null,location.href)
            }
        </script>
        </table>

        <br><br><br>
    
            <div id="footerDiv">
                <p>Powered by Me</p>
            </div>
        
    </div>


    <script>
        /* When the user clicks on the button, 
        toggle between hiding and showing the dropdown content */
        function myFunction() {
          document.getElementById("myDropdown").classList.toggle("show");
        }

        function myFunctionRepo() {
          document.getElementById("myDropdownRepo").classList.toggle("show");
        }

        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }
        
        // Close the dropdown if the user clicks outside of it
        window.onclick = function(event) {
          if (!event.target.matches('.dropbtn')) {
            var dropdowns = document.getElementsByClassName("dropdown-content");
            var i;
            for (i = 0; i < dropdowns.length; i++) {
              var openDropdown = dropdowns[i];
              if (openDropdown.classList.contains('show')) {
                openDropdown.classList.remove('show');
              }
            }
          }
        }

        
        </script>
    
</body>
</html>