<?php
session_start();
// For Secure URL / do not permission enter by url type
if($_SESSION['employeeId'] == true){
    // after login fetch email address and password display from database into this page
    echo("<h3>Your Id : $_SESSION[employeeId]</h3>");
} else{
    header('Location: login.php');
}

    // Database Connection with mysql database
    $connection = mysqli_connect("localhost", "root", "", "ddcl_library_book_entry_db");

    $id = $_GET['idNo'];

    //For Show Data in Delete page input field
    $delete = "DELETE FROM daily_update_tb WHERE Id = $id";
    $query = mysqli_query($connection, $delete);
    
    if($query){
        header("location:dailyUpdate.php");
    } else{
        echo "<script>alert('Data Delete Fail')</script>";
    }

?>