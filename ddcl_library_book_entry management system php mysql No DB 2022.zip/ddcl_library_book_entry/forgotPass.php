<?php
// For Store data
session_start();
//database connection
$connection = mysqli_connect('localhost','root','','ddcl_library_book_entry_db');
//database connection check
if($connection){
    // echo "Connection Success";
} else{
    echo "Connection Failed";
}

if(isset($_POST['submit']))
{
    $employeeId = $_POST['employeeId'];
    $result = mysqli_query($connection,"SELECT * FROM registration_table where employeeId='" . $_POST['employeeId'] . "'");
    $row = mysqli_fetch_assoc($result);
	$fetch_user_id=$row['employeeId'];
	$email=$row['email'];
	$password=$row['password'];
	if($employeeId==$fetch_user_id) {
				$to = $email;
                $subject = "Password";
                $txt = "Your password is : $password.";
                $headers = "From: ahmadnesar898@gmail.com" . "\r\n" .
                "CC: somebodyelse@example.com";
                mail($to,$subject,$txt,$headers);
			}
				else{
					echo 'invalid userid';
				}
}

?>

<!DOCTYPE HTML>
<html>
<head>
<style type="text/css">
 input{
 border:1px solid olive;
 border-radius:5px;
 }
 h1{
  color:darkgreen;
  font-size:22px;
  text-align:center;
 }
 h2{
  color:red;
  font-size:22px;
  text-align:center;
 }

</style>
</head>
<body>
<h1>Forgot Password<h1>
<form action='' method='post'>
<table cellspacing='5' align='center'>
<tr><td>Employee ID:</td><td><input type='text' name='employeeId'/></td></tr>
<tr><td></td><td><input type='submit' name='submit' value='Submit' disabled/></td></tr>
<br><br>
</table>
<a href="login.php">Go Back</a>
</form>
<h2>Under Construction</h2>
</body>
</html>